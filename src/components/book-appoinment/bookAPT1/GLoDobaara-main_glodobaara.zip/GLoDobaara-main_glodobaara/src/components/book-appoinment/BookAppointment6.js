import React from "react";
import "./bookAppointment6.css";
import BookingHeader from "./book-appoinment-components/BookingHeader";
import Footer1 from "../footer1/Footer_1";
import image from "./images/booking_page6.png";
import DragAndDropBox from "./book-appoinment-components/DragAndDropFiles";
import BookBanner from "./BookBanner";
export default function BookAppointment6() {
  return (
    <>
      <BookBanner />
      <div className="center-content">
        <div className="context-image">
          <img src={image} />
        </div>
        <div className="content-div">
          <DragAndDropBox />
        </div>
      </div>
      <Footer1 />
    </>
  );
}
