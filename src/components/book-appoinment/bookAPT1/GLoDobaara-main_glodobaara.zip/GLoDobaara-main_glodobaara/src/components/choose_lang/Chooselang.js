import React from "react";
import { useState } from "react";
import "./chooselang.css";
import BookingHeader from "../book-appoinment/book-appoinment-components/BookingHeader";
import BookingProgressBar from "../book-appoinment/book-appoinment-components/BookingProgressBar";
import Lskills from "./Group 110.png";
import RadioButtonwoImage from "./components/RadioButtonwoImage";
import Footer1 from "../footer1/Footer_1";
import Footer_2 from "../footer2/Footer_2";
import BottomButtonGroup from "./components/BottomButtonGrCS";
import Dropdown from "../choose_lang/components/Dropdown";
export default function Chooselang() {
  const [drawer, setState] = useState(false);
  function handleChange(value) {
    setState(value);
  }
  return (
    <>
      <BookingHeader />
      <BookingProgressBar
        txt1="Schedule A Class"
        txt2="Choose the language that you want to learn"
        value="1"
      />
      <div className="cl-middle-part">
        <div className="cl-image-div">
          <img src={Lskills} className="cl-left-image" alt="LearnSkills"></img>
        </div>
        <div className="cl-maincontent">
          <div className="cl-sub-content">
            <RadioButtonwoImage
              title="English (US)"
              onClick={() => {
                handleChange("English (US)");
              }}
              checked={drawer}
            />
            <RadioButtonwoImage
              title="English (UK)"
              onClick={() => {
                handleChange("English (UK)");
              }}
              checked={drawer}
            />
            <RadioButtonwoImage
              title="French"
              onClick={() => {
                handleChange("French");
              }}
              checked={drawer}
            />
          </div>

          <div className="cl-drpdwn">
            <div>{drawer === "English (US)" ? <Dropdown /> : null}</div>
            <div>{drawer === "English (UK)" ? <Dropdown /> : null}</div>
            <div>{drawer === "French" ? <Dropdown /> : null}</div>
          </div>
          <div className="cl-subcontent">
            <RadioButtonwoImage
              title="English (chatting???)"
              onClick={() => {
                handleChange("English (chatting???)");
              }}
              checked={drawer}
            />
            <RadioButtonwoImage
              title="Arabic"
              onClick={() => {
                handleChange("Arabic");
              }}
              checked={drawer}
            />
            <RadioButtonwoImage
              title="Sanskrit"
              onClick={() => {
                handleChange("Sanskrit");
              }}
              checked={drawer}
            />
          </div>
          <div className="cl-drpdwn">
            <div>
              {drawer === "English (chatting???)" ? <Dropdown /> : null}
            </div>
            <div>{drawer === "Arabic" ? <Dropdown /> : null}</div>
            <div>{drawer === "Sanskrit" ? <Dropdown /> : null}</div>
          </div>
          <div className="cl-sub-subcontent">
            <RadioButtonwoImage
              title="Spanish"
              onClick={() => {
                handleChange("Spanish");
              }}
              checked={drawer}
            />
            <RadioButtonwoImage
              title="Japanese"
              onClick={() => {
                handleChange("Japanese");
              }}
              checked={drawer}
            />
          </div>
          <div className="cl-drpdwn">
            <div>{drawer === "Spanish" ? <Dropdown /> : null}</div>
            <div>{drawer === "Japanese" ? <Dropdown /> : null}</div>
          </div>
          <BottomButtonGroup />
        </div>
      </div>
      <Footer1 />
    </>
  );
}
