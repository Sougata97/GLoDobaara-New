import React, { useState } from "react";
import {
  FaAngleDown,
  FaEnvelope,
  FaLocationArrow,
  FaPhoneAlt,
  FaRegWindowClose,
} from "react-icons/fa";
import "./bookingPopup.css";
import ThankYouPopup from "./ThankYouPopup";

function BookingPopup(props) {
  const [bookingData, setData] = useState({
    name: "",
    email: "",
    phone: "",
    service: "",
  }); //useState for bookingData

  function handleChange(event) {
    const { name, value } = event.target;
    setData({
      ...bookingData,
      [name]: value,
    }); //Based on where you call this function it will change the booking data correspondingly
  } //This function is responsible for handling change of bookingData
  const [popupState, setState] = useState(true); //popupState is the value based on which popup pages render
  function handleState() {
    setState(false);
  } //This function is responsible for rendering the next page of the popup(Thank You page)

  const [dropDownMenu, dropDownState] = useState(false);
  function handleDropDownChange() {
    dropDownState(!dropDownMenu);
  } //Upon calling this function the dropdown menu will be visible

  const [dropDownValue, dropDownValueState] = useState("");
  function handleDropDownValue(event) {
    dropDownValueState(event.target.value);
    bookingData.service = event.target.value;
    const textField = document.getElementById("service");
    textField.setAttribute("value", event.target.value);
    dropDownState(!dropDownMenu); //This line will close the drop down menu
  } //This function will set the value of bookingdata.services based on the option you choose from the dropdown menu

  function saveData() {
    const json = JSON.stringify(bookingData);
    console.log(json);
    // const blob = new Blob([json], { type: "application/json" });
    // const url = URL.createObjectURL(blob);
    // const link = document.createElement("a");
    // link.href = url;
    // link.download = "Booking Request " + bookingData["name"];
    // link.click();
    // URL.revokeObjectURL(url);
  } //This function downloads the booking form data as a JSON file

  return popupState ? (
    <div className="pop-cont">
      <FaRegWindowClose
        className="pop-close-icon"
        onClick={props.closeButtonFunction}
        //props.closeButtonFunction parameter is necessary in order to close the popup onClick on cross button
      />
      <div className="pop-content-div">
        <div className="pop-info">
          <p>Contact Us</p>
          <h2>Get In Touch With Us</h2>
          <h5>
            Lorem Ipsum has been the industry's standard dummy text ever since
            the 1500s, when an unknown printer took a galley of type and
            scrambled it to make a type specimen book.
          </h5>
          <div className="pop-contact-info">
            <div className="pop-icon-cont">
              <FaLocationArrow className="pop-icon" />
            </div>
            <div className="pop-icon-cont-info-text">
              <h3>Our Location</h3>
              <h5>
                Lorem Ipsum has been<br></br> dummy text the 1500s,
              </h5>
            </div>
          </div>
          <div className="pop-contact-info">
            <div className="pop-icon-cont">
              <FaPhoneAlt className="pop-icon" />
            </div>
            <div className="pop-icon-cont-info-text">
              <h3>Phone Number</h3>
              <h5>(+91)1235535975461</h5>
            </div>
          </div>
          <div className="pop-contact-info">
            <div className="pop-icon-cont">
              <FaEnvelope className="pop-icon" />
            </div>
            <div className="pop-icon-cont-info-text">
              <h3>Email Address</h3>
              <h5>info@jheiufiewi.com</h5>
            </div>
          </div>
        </div>
        <div className="pop-form">
          <fieldset>
            <legend>Your Name</legend>
            <input
              type="text"
              className="pop-inp"
              name="name"
              placeholder="Enter Name"
              onChange={handleChange}
            />
          </fieldset>
          <fieldset>
            <legend>Your Email</legend>
            <input
              type="text"
              className="pop-inp"
              name="email"
              placeholder="Enter Your Email Id"
              onChange={handleChange}
            />
          </fieldset>
          <fieldset>
            <legend>Your Phone</legend>
            <input
              type="text"
              className="pop-inp"
              name="phone"
              placeholder="Enter Your Phone No."
              onChange={handleChange}
            />
          </fieldset>
          <fieldset className="pop-form-drbdwn-inp ">
            <legend>Choose Services</legend>
            <input
              type="text"
              className="pop-inp"
              name="service"
              placeholder="Select Service"
              onChange={handleChange}
              id="service"
            />
            <button
              className="pop-form-drbdwn-btn"
              onClick={handleDropDownChange}
            >
              <FaAngleDown className="drbdwn-btn-icon" />
            </button>
          </fieldset>
          {dropDownMenu ? (
            <div className="drpdwn-menu">
              <button
                className="drpdwn-menu-ops"
                value="service1"
                onClick={handleDropDownValue}
              >
                Service 1
              </button>
              <button
                className="drpdwn-menu-ops"
                value="service2"
                onClick={handleDropDownValue}
              >
                Service 2
              </button>
              <button
                className="drpdwn-menu-ops"
                value="service3"
                onClick={handleDropDownValue}
              >
                Service 3
              </button>
              <button
                className="drpdwn-menu-ops"
                value="service4"
                onClick={handleDropDownValue}
              >
                Service 4
              </button>
              <button
                className="drpdwn-menu-ops"
                value="service5"
                onClick={handleDropDownValue}
              >
                Service 5
              </button>
            </div>
          ) : null}

          <button
            onClick={() => {
              handleState(); //Renders next page of the popup
              saveData(); //downloads booking data
            }}
          >
            SUBMIT
          </button>
        </div>
      </div>
    </div>
  ) : (
    <ThankYouPopup closeButtonFunction={props.closeButtonFunction} />
  );
}

export default BookingPopup;
