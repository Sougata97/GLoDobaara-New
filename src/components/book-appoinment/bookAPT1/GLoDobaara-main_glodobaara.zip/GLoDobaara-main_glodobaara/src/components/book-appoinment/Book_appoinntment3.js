import React from "react";
import "./booktwo.css";
import leftArrow from "./images/leftArrow.png";
import rightArrow from "./images/rightArrow.png";
import back from "./images/back.png";
import next from "./images/next.png";
import chooseImg from "./images/choose_img.png";
import durationAlarm from "./images/duration.png";

export default function Book_appointment3() {
  return (
    <>
      <section className="bookapmt2">
        <div className="container">
          <div className="book-heading">
            <h2>Book Appointment</h2>
            <p>Let's Spend A Quality Time Together</p>
            <span></span>
            <span className="pink"></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
          </div>
          <div className="apointment2maincontent">
            <div className="apt2-wrap-left">
              <img src={chooseImg} alt="" />
            </div>
            <div className="apt2-wrap-right">
              <div className="monthapt2">
                <h2>MARCH 2023</h2>
              </div>
              <div className="apt2dates">
                <div className="apt2dates_box">
                  <button>
                    <img src={leftArrow} alt="" />
                  </button>
                </div>
                <div className="apt2dates_box">
                  Sun <br /> 05
                </div>
                <div className="apt2dates_box">
                  Mon <br /> 06
                </div>
                <div className="apt2dates_box">
                  Tue <br /> 07
                </div>
                <div className="apt2dates_box">
                  Wed <br /> 08
                </div>
                <div className="apt2dates_box">
                  Thu <br /> 09
                </div>
                <div className="apt2dates_box">
                  Fri <br /> 10
                </div>
                <div className="apt2dates_box">
                  Sat <br /> 11
                </div>
                <div className="apt2dates_box">
                  <button>
                    <img src={rightArrow} alt="" />
                  </button>
                </div>
              </div>
              <div className="apt2times">
                <div className="apt2timeswrap">
                  <ul className="apt2timeul">
                    <li>
                      <label class="container-radio ">
                        09:30 am
                        <input type="radio" name="apt2radio" />
                        <span class="checkmark"></span>
                      </label>
                    </li>
                    <li>
                      <label class="container-radio ">
                        09:00 am
                        <input type="radio" name="apt2radio" />
                        <span class="checkmark"></span>
                      </label>
                    </li>
                    <li>
                      <label class="container-radio ">
                        10:00 am
                        <input type="radio" name="apt2radio" />
                        <span class="checkmark"></span>
                      </label>
                    </li>
                    <li>
                      <label class="container-radio ">
                        10:30 am
                        <input type="radio" name="apt2radio" />
                        <span class="checkmark"></span>
                      </label>
                    </li>
                    <li>
                      <label class="container-radio ">
                        11:00 am
                        <input type="radio" name="apt2radio" />
                        <span class="checkmark"></span>
                      </label>
                    </li>
                    <li>
                      <label class="container-radio ">
                        11:30 am
                        <input type="radio" name="apt2radio" />
                        <span class="checkmark"></span>
                      </label>
                    </li>
                  </ul>
                </div>
                <div className="apt2timeswrap">
                  <ul className="apt2timeul">
                    <li>
                      <label class="container-radio ">
                        12:00 pm
                        <input type="radio" name="apt2radio" />
                        <span class="checkmark"></span>
                      </label>
                    </li>
                    <li>
                      <label class="container-radio ">
                        12:15 pm
                        <input type="radio" name="apt2radio" />
                        <span class="checkmark"></span>
                      </label>
                    </li>
                    <li>
                      <label class="container-radio ">
                        12:30 pm
                        <input type="radio" name="apt2radio" />
                        <span class="checkmark"></span>
                      </label>
                    </li>
                    <li>
                      <label class="container-radio ">
                        12:45 pm
                        <input type="radio" name="apt2radio" />
                        <span class="checkmark"></span>
                      </label>
                    </li>
                    <li>
                      <label class="container-radio ">
                        01:00 pm
                        <input type="radio" name="apt2radio" />
                        <span class="checkmark"></span>
                      </label>
                    </li>
                  </ul>
                </div>
                <div className="apt2timeswrap">
                  <ul className="apt2timeul">
                    <li>
                      <label class="container-radio ">
                        01:30 pm
                        <input type="radio" name="apt2radio" />
                        <span class="checkmark"></span>
                      </label>
                    </li>
                    <li>
                      <label class="container-radio ">
                        02:00 pm
                        <input type="radio" name="apt2radio" />
                        <span class="checkmark"></span>
                      </label>
                    </li>
                    <li>
                      <label class="container-radio ">
                        02:30 pm
                        <input type="radio" name="apt2radio" />
                        <span class="checkmark"></span>
                      </label>
                    </li>
                    <li>
                      <label class="container-radio ">
                        03:00 pm
                        <input type="radio" name="apt2radio" />
                        <span class="checkmark"></span>
                      </label>
                    </li>
                    <li>
                      <label class="container-radio ">
                        03:30 pm
                        <input type="radio" name="apt2radio" />
                        <span class="checkmark"></span>
                      </label>
                    </li>
                    <li>
                      <label class="container-radio ">
                        04:00 pm
                        <input type="radio" name="apt2radio" />
                        <span class="checkmark"></span>
                      </label>
                    </li>
                    <li>
                      <label class="container-radio ">
                        04:30 pm
                        <input type="radio" name="apt2radio" />
                        <span class="checkmark"></span>
                      </label>
                    </li>
                    <li>
                      <label class="container-radio ">
                        05:00 pm
                        <input type="radio" name="apt2radio" />
                        <span class="checkmark"></span>
                      </label>
                    </li>
                    <li className="apt3-active">
                      <label class="container-radio ">
                        05:30 pm
                        <input type="radio" name="apt2radio" />
                        <span class="checkmark"></span>
                      </label>
                    </li>
                  </ul>
                </div>
                <div className="apt2timeswrap">
                  <ul className="apt2timeul">
                    <li>
                      <label class="container-radio ">
                        06:00 pm
                        <input type="radio" name="apt2radio" />
                        <span class="checkmark"></span>
                      </label>
                    </li>
                    <li>
                      <label class="container-radio ">
                        06:30 pm
                        <input type="radio" name="apt2radio" />
                        <span class="checkmark"></span>
                      </label>
                    </li>
                    <li>
                      <label class="container-radio ">
                        07:00 pm
                        <input type="radio" name="apt2radio" />
                        <span class="checkmark"></span>
                      </label>
                    </li>
                    <li>
                      <label class="container-radio ">
                        07:30 pm
                        <input type="radio" name="apt2radio" />
                        <span class="checkmark"></span>
                      </label>
                    </li>
                    <li>
                      <label class="container-radio ">
                        08:00 pm
                        <input type="radio" name="apt2radio" />
                        <span class="checkmark"></span>
                      </label>
                    </li>
                    <li>
                      <label class="container-radio ">
                        08:30 pm
                        <input type="radio" name="apt2radio" />
                        <span class="checkmark"></span>
                      </label>
                    </li>
                    <li>
                      <label class="container-radio ">
                        09:00 pm
                        <input type="radio" name="apt2radio" />
                        <span class="checkmark"></span>
                      </label>
                    </li>
                    <li>
                      <label class="container-radio ">
                        09:30 pm
                        <input type="radio" name="apt2radio" />
                        <span class="checkmark"></span>
                      </label>
                    </li>
                    <li>
                      <label class="container-radio ">
                        10:00 pm
                        <input type="radio" name="apt2radio" />
                        <span class="checkmark"></span>
                      </label>
                    </li>
                  </ul>
                </div>
              </div>
              <div className="apt2duration_select">
                <fieldset>
                  <legend>Duration</legend>
                  <div className="duration_box">
                    <div className="duration-box-left">
                      <img src={durationAlarm} alt="" />
                    </div>
                    <div className="duration-box-right">
                      <div className="custom-select">
                        <div className="select">
                          <select>
                            <option value="1">1 hour</option>
                            <option value="2">2 hour</option>
                            <option value="3">3 hour</option>
                            <option value="4">4 hour</option>
                            <option value="5">5 hour</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                </fieldset>
              </div>
              <div className="apt2-btns">
                <div className="apt2-btns_left">
                  <a href="#">
                    <img src={back} alt="" /> Back
                  </a>
                </div>
                <div className="apt2-btns_right">
                  <a href="#">Cancel</a>
                  <a href="#">
                    Next
                    <img src={next} alt="" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
