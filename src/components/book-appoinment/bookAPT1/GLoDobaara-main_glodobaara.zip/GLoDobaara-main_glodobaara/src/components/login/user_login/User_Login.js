import React from "react";
import "./user_login.css";

export default function UserLogin() {
  return (
    <div className="User_container">
      <div className="usr-lg">
        <h2>SIGN IN</h2>
        <p>SIGN IN USING YOUR GMAIL</p>
        <p>(If you are already logged in on the device)</p>
        <h2>OR</h2>
        <form className="usr-lg-frm">
          <p>SIGN IN USING YOUR</p>
          <div className="usr-lg-rdb">
            <label></label>
            <input type="Radio" />
          </div>
          <p>SIGN IN USING YOUR</p>
          <div className="usr-lg-rdb">
            <label>
              <label>Phone</label>
              <label></label>
            </label>
            <input type="Radio" />
          </div>
          <p>VERIFY YOUR OTP</p>
          <input></input>
          <p>RESEND OTP</p>
          <button>SUBMIT</button>
        </form>
        <div>
          <a href="#">Don't Have an ACCOUNT?</a>
        </div>
        <div>
          <a href="#">Sign Up</a>
        </div>
      </div>
    </div>
  );
}
