import React from "react";
import Popup from "reactjs-popup";
import BookingPopup from "../popup/BookingPopup";
export default function Our_serv_box1(props) {
  return (
    <>
      <div className="box">
        <div className="img">
          <img src={props.img} alt="" />
        </div>
        <div className="text">
          <p>{props.p}</p>
          <a href={props.link} className="btn">
            <Popup
              trigger={<span onClick={props.onClick}>{props.btn_text}</span>}
              position="center center"
              closeOnDocumentClick
              className="overlay"
              closeOnEscape
              repositionOnResize
            >
              {(close) => <BookingPopup closeButtonFunction={close} />}
            </Popup>
          </a>
        </div>
      </div>
    </>
  );
}
