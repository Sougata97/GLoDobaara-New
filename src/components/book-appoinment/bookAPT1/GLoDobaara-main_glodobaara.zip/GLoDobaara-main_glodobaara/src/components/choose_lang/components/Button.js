import React from "react";
import "./button.css";
export default function Button(props) {
  return (
    <>
      <div className="btn-maincontainer" onClick={props.onClick}>
        <div className="btn-main">
          <div className="btn-leftalign">
            <input
              type="radio"
              id={props.title}
              name="radio"
              value={props.value}
              checked={props.title === props.checked}
            />
          </div>
          <label>
            <div className="btn-text">
              <p>{props.txt}</p>
            </div>
          </label>
        </div>
      </div>
    </>
  );
}
// type="radio"
//           className="hd-input-button"
//           id={props.title}
//           name="radio"
//           value={props.value}
//           onClick={props.onClick}
//           checked={props.checked}
