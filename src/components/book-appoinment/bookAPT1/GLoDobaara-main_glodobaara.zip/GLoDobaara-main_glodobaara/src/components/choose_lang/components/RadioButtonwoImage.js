import React from "react";
import "./radiobtn.css";
export default function RadioButtonwoImage(props) {
  return (
    <>
      <label className="hd-radioButton" onClick={props.onClick}>
        <label className="hd-name">
          <p>{props.title}</p>
        </label>
        <input
          type="radio"
          className="hd-input-button"
          id={props.title}
          name="radio"
          value={props.title}
          checked={props.title === props.checked}
        />
      </label>
    </>
  );
}
