import React, { useState } from "react";
import "./dropdwn.css";
import Button from "./Button";
export default function Dropdown() {
  const [isActive, setState] = useState("");
  const [purpose, setPurposeState] = useState("");
  function handleChange(id) {
    setState(id);
  }
  function handleChangePurposeChange(id) {
    setPurposeState(id);
  }
  return (
    <>
      <div className="dd-main-container">
        <div className="first-box">
          <fieldset>
            <legend>Choose your proficiency level</legend>
            <div className="first-inside-box">
              <Button
                txt="Speaking"
                onClick={() => handleChange("option 1")}
                title="option 1"
                checked={isActive}
              />
              <Button
                txt="Writing & Reading"
                onClick={() => handleChange("option 2")}
                title="option 2"
                checked={isActive}
              />
              <Button
                txt="Chatting through social media"
                onClick={() => handleChange("option 3")}
                title="option 3"
                checked={isActive}
              />
            </div>
          </fieldset>
        </div>
        <div className="second-box">
          <fieldset>
            <legend>What you want to achieve</legend>
            <div className="second-inside-box">
              <div className="inside-box">
                <div className="inside-box-one">
                  <input
                    type="radio"
                    name="purpose"
                    value="purpose 1"
                    checked={purpose === "purpose 1"}
                  />
                  <p
                    onClick={() => {
                      setPurposeState("purpose 1");
                    }}
                  >
                    I want to be prepared while I go a broad
                  </p>
                </div>
                <div className="inside-box-one">
                  <input
                    type="radio"
                    name="purpose"
                    value="purpose 2"
                    checked={purpose === "purpose 2"}
                  />
                  <p
                    onClick={() => {
                      setPurposeState("purpose 2");
                    }}
                  >
                    I want to be confident to speak with my grandson /
                    granddaughter who speak different language
                  </p>
                </div>
                <div className="inside-box-one">
                  <input
                    type="radio"
                    name="purpose"
                    value="purpose 3"
                    checked={purpose === "purpose 3"}
                  />
                  <p
                    onClick={() => {
                      setPurposeState("purpose 3");
                    }}
                  >
                    I want to learn holi books in original form
                  </p>
                </div>
              </div>
              <div></div>
            </div>
          </fieldset>
        </div>
      </div>
    </>
  );
}
